function out = apply_SpicyMKL(C, F)

[mte,mtr,nn]=size(F);

F = permute(F, [3, 1, 2]);

F = reshape(C.d*F(:,:), [mte, mtr]);

out = F*C.alpha+C.bias;