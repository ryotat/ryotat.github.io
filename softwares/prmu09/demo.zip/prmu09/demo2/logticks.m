function tics = logticks(ax, lim, base)

if ~exist('lim','var') || isempty(lim)
  lim = get(gca, [ax, 'lim']);
end

if ~exist('base','var') || isempty(base)
  base = 10;
end


if lim(2)-lim(1)>log(base)
  lim(1) = floorby(lim(1),log(base));
  lim(2) = ceilby(lim(2),log(base));
  ticks = lim(1):log(base):lim(2);
else
  set(gca, [ax 'tickmode'], 'auto');
  
  ticks = get(gca,[ax 'tick']);
end


ticklab = foreach(@num2str_base, num2cell(exp(ticks)), [], base);

set(gca,[ax 'tick'], ticks,...
        [ax 'ticklabel'], ticklab);

