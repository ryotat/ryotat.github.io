function y = ceilby(x, c)

y = ceil(x/c)*c;