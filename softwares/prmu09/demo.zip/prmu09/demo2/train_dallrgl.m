function C=train_dallrgl(F, Y, lambda)

[mm,ns,nc]=size(F);

[ww,bb,stat]=dallrgl(zeros(ns,nc),F(:,:),Y(:), lambda,'display',1);

C = struct('w',ww,'bias',bb,'stat',stat);