function [Am, As, divTr, divTe, output, memo]=xvalidation(X, Y, model, ...
                                                  lambda, nTrials, varargin)

opt=propertylist2struct(varargin{:});
opt=set_defaults(opt, 'preproc', 'meandiffs');


[divTr,divTe]=sample_divisions(Y,nTrials);

if isequal(unique(Y),[0 1])
  Y=2*Y-1;
end

if size(Y,1)<size(Y,2)
  Y=Y';
end

A=zeros([nTrials, length(lambda)]);

memo=repmat(struct('C',[],'out',[],'acc',[]),...
            [nTrials,length(lambda)]);

output=zeros(nTrials(1),length(Y),length(lambda));

for ii=1:nTrials(1)
  for jj=1:nTrials(2)
    fcn_preproc=['preproc_' opt.preproc];
    [Ftr,optproc]=feval(fcn_preproc, X(divTr{ii,jj}), X(divTr{ii,jj}),opt);
    Ytr=Y(divTr{ii,jj});
    
    Fte=feval(fcn_preproc,X(divTr{ii,jj}),X(divTe{ii,jj}),optproc);
    Yte=Y(divTe{ii,jj});
    
    for kk=1:length(lambda)
      fprintf('Fold:%d of Split:%d lambda=%g\n', jj, ii, lambda(kk));
      C=feval(['train_' model], Ftr, Ytr, lambda(kk));
      out=feval(['apply_' model], C, Fte);
      acc=mean(Yte(:).*out>0);
      
      A(ii,jj,kk)=acc;
      memo(ii,jj,kk)=struct('C',C,...
                            'out',out,...
                            'acc',acc);
      output(ii,divTe{ii,jj},kk)=out;
    end
  end
end

Am=mean(A,2);
As=shiftdim(std(Am,[],1));
Am=shiftdim(mean(Am,1));