% F = meandiffs(X)
function F = meandiffs(X)

if iscell(X)
  F=cell(size(X));
  for ii=1:prod(size(F))
    F{ii}=meandiffs(X{ii});
  end
else
  [m,n]=size(X);

  X(isnan(X))=0;
  
  F=zeros(3,n);

  F(1,:)=mean(X,1);
  F(2,:)=mean(diff(X),1);
  F(3,:)=mean(diff(X,2),1);
end
