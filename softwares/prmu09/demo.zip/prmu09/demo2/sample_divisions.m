function [divTr, divTe]=sample_divisions(Y, nTrials)

nn = length(Y);

divTr=cell(nTrials);
divTe=cell(nTrials);


for ii=1:nTrials(1)
  I=randperm(nn);
  i2=0;
  for jj=1:nTrials(2)
    i1=i2+1; i2=round(nn*jj/nTrials(2));
    Ite =sort(I(i1:i2));
    divTr{ii,jj} =setdiff(1:nn, Ite);
    divTe{ii,jj} =Ite;
  end
end
