function str = num2str_base(x, base);

ep = log(x)/log(base);

str = sprintf('%d^{%g}',base,ep);