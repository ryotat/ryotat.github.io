function out = apply_dallrgl(C, F)

out = F(:,:)*C.w(:)+C.bias;