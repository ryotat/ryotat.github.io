function y = floorby(x, c)

y = floor(x/c)*c;