function [F,opt] = preproc_triplets(Xtr, Xte, varargin)

%% Center and scale the data to unit varaince
[Xtr,opt]=preproc_scalecenter(Xtr,varargin{:});
Xte=preproc_scalecenter(Xte,opt);

%% Take only t=0
for ii=1:length(Xtr), Xtr{ii}=Xtr{ii}(1,:); end
for ii=1:length(Xte), Xte{ii}=Xte{ii}(1,:); end 

Xtr=cell2mat(Xtr);
Xte=cell2mat(Xte);

nn=size(Xtr,2);
if nn~=size(Xte,2)
  error('Size of Xtr and Xte are different.');
end

if isfield(opt,'ixtr') && length(opt.ixtr)>0
  ncomb = length(opt.ixtr);
else
  ncomb=nn*(nn-1)*(nn-2)/6;
  opt.ixtr=[];
end

%% Polynomial order
if ~isfield(opt,'polyorder')
  opt.polyorder=2;
end
if ~isfield(opt,'tr')
  if ~isequal(Xtr,Xte)
    error('Xtr and Xte seems to be different but no opt.tr given.');
  end
  opt.tr=zeros(1,ncomb);
end

if length(opt.ixtr)>0
  F=zeros(size(Xte,1),size(Xtr,1), ncomb);
  for ii=1:ncomb
    F(:,:,ii)=(1+Xte(:,opt.ixtr{ii})*Xtr(:,opt.ixtr{ii})').^opt.polyorder;

    if opt.tr(ii)==0
      opt.tr(ii)=trace(F(:,:,ii));
    end

    F(:,:,ii)=F(:,:,ii)/opt.tr(ii);
  end
else
  F=zeros(size(Xte,1),size(Xtr,1), ncomb);
  opt.ixtr=cell(1,ncomb);

  ind=1;
  for kk=1:nn
    for jj=kk+1:nn
      for ii=jj+1:nn
        F(:,:,ind)=(1+Xte(:,[kk,jj,ii])*Xtr(:,[kk,jj,ii])').^opt.polyorder;
        
        if opt.tr(ind)==0
          opt.tr(ind)=trace(F(:,:,ind));
        end
        F(:,:,ind)=F(:,:,ind)/opt.tr(ind);
        
        opt.ixtr{ind}=[kk,jj,ii];
        
        ind=ind+1;
      end
    end
  end
end



