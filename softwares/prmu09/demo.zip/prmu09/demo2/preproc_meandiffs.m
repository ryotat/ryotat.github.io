function [F,opt] = preproc_meandiffs(Xtr, Xte, varargin)

X=Xte;

[X,opt]=preproc_scalecenter(X,varargin{:});

n=size(X{1},2);

F=zeros(length(X),3,n);
for ii=1:length(X)
  F(ii,1,:)=mean(X{ii},1);
  F(ii,2,:)=mean(diff(X{ii}),1);
  F(ii,3,:)=mean(diff(X{ii},2),1);
end


