function [X,opt]=preproc_scalecenter(X,opt)

if iscell(X)
  if size(X,1)<size(X,2)
    X=X';
  end

  L=zeros(size(X));
  for ii=1:length(X)
    L(ii)=size(X{ii},1);
  end

  X=cell2mat(X);
else
  L=size(X,1);
end

if ~exist('opt','var') || ~isfield(opt,'mm') || ~isfield(opt,'ss')
  opt.mm=mean(X);
  opt.ss=std(X);
end

X=(X-ones(sum(L),1)*opt.mm)/diag(opt.ss);

X=mat2cell(X,L,size(X,2));
