%% Nine triplets identified by Baranzini et al. to be discriminative
ixtrip = {[36, 44, 49],...
          [36 37 54],...
          [36 41 54],...
          [4 36 54],...
          [44 54 62],...
          [10 44 62],...
          [28 36 52],...
          [4 36 37],...
          [36 54 56]};


addpath ../SpicyMKL/

S=importdata('journal.pbio.0030002.sd001.xls');

Ytmp=cell2mat(foreach(@isequal,S.textdata.Sheet1(2:end,1),[],'good'));

Gene=S.textdata.Sheet1(1,7:end-6);

id_sbj=S.data.Sheet1(:,1);  [tmp,I]=unique(id_sbj); code=id_sbj(sort(I));

Ttmp=S.textdata.Sheet1(2:end,3);
Xtmp=S.data.Sheet1(:,6:end-6); 

% Clean up the data
ix = [153, 211];
Xtmp(ix,:)=[]; id_sbj(ix)=[]; Ytmp(ix)=[]; Ttmp(ix)=[];

Xtmp(isnan(Xtmp))=0;


% Collect subjects into cells
Y=zeros(1,length(code));
X=cell(1,length(code));
T=cell(1,length(code));
L=zeros(1,length(code));
for ii=1:length(code)
  I=find(id_sbj==code(ii));
  Y(ii)=mean(Ytmp(I));
  X{ii}=Xtmp(I,:);
  T{ii}=Ttmp(I);
  L(ii)=length(I);
  if ~isequal(T{ii}{1},'t0')
    display(I);
    display(T{ii});
    warning('Index seems to be wrong!');
  end
end

%% Reject the last example because it lacks sample for t=0
X(end)=[];
Y(end)=[];

%% Perform cross-validation
xTrials = [10 4];
lambda=exp(linspace(log(0.8),log(0.008),10));
[Am, As,divTr,divTe,output,memo]=xvalidation(X,Y,'SpicyMKL',lambda,xTrials,'preproc','best_triplets','ixtr',ixtrip);



%% Plot accuracy
figure, h=errorbar(log(lambda), Am, As);
set(gca,'fontsize',16);
set(h,'linewidth',2);
grid on;
logticks('x');
set(gca,'position',[0.13, 0.2 0.775, 0.75])
xlabel('Regularization constant');
ylabel('Accuracy');
format_ticks(gca,get(gca,'xticklabel'))
xlim(log([0.007 1]))

hold on;
plot(xlim,0.878*ones(1,2),'--','color',[0 .5 0],'linewidth',2);

legend('SpicyMKl','Single best (Baranzini et al.)')

%% Plot kernel weights
ds=zeros(prod(xTrials), length(ixtrip));
for kk=1:prod(xTrials)
  [ii,jj]=ind2sub(xTrials,kk);
  ds(kk,:)=memo(ii,jj,5).C.d;
end

for ii=1:length(ixtrip), lab{ii}=[Gene{ixtrip{ii}(1)} '/' Gene{ixtrip{ii}(2)} '/' Gene{ixtrip{ii}(3)} '  ']; end
figure, plot(mean(ds),'linewidth',2);
set(gca,'fontsize',12)                 
set(gca,'position',[0.25 0.4 0.7 0.5]) 
set(gca,'xtick',1:length(ixtrip))                   
format_ticks(gca,lab,[],[],[],45);
grid on;
title('Kernel weights')
set(gcf,'paperpositionmode','auto')   
