function h = polynomial_kernel(x1,x2,d)
    h = ((x1*x2')+1)^d; 

    
