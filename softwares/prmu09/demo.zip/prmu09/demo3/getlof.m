function S=getlof(dir)

T=ls(dir,'-1');

I=find(T==char(10));

S=cell(1,length(I));
ix0=1;
for ii=1:length(I)
  S{ii}=T(ix0:I(ii)-1);
  ix0=I(ii)+1;
end
