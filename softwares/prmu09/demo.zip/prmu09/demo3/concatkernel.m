function  Kout = concatkernel(K,d)

Kout = zeros(size(K,1),size(K,2));
for i=1:size(K,3)
    Kout = Kout + d(i)*K(:,:,i);
end;

