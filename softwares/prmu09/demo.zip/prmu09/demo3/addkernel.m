function K = addkernel(K,K1)
    K(:,:,end+1:end+size(K1,3)) = K1;