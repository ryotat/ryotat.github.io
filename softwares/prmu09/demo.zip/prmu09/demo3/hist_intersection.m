function h = hist_intersection(hist1,hist2)
    h = sum(min([hist1;hist2]));

    
