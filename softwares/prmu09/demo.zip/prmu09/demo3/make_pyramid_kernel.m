function K = make_pyramid_kernel(W,Finfo,npoints,L,kernel_func,mode)
%mode=0: pyramid kernel
%mode=1: kernels on each region will be outputed.
%mode=2: 0 and 1.

num_sample = length(npoints);
code_words = unique(W);

kernel_count = 0;
for l=0:L
    llcount = 0;
    for ll1=1:2^l
        for ll2=1:2^l
            
            llcount = llcount + 1;
            
            Htmp{llcount} = zeros(num_sample,length(code_words));
            %Htmp = zeros(num_sample,4^l);
            for i=1:num_sample
                start_ind = sum(npoints(1:i)) - npoints(i) + 1;
                end_ind = start_ind + npoints(i) - 1;
                ind = start_ind:end_ind;
                xlims = [min(Finfo(ind,1)) max(Finfo(ind,1))];
                ylims = [min(Finfo(ind,2)) max(Finfo(ind,2))];
                unitx = (xlims(2)-xlims(1))/(2^l);
                unity = (ylims(2)-ylims(1))/(2^l);
                ind2 = find((unitx*(ll1-1) < Finfo(ind,1)) & (unitx*(ll1) >= Finfo(ind,1)) & (unity*(ll2-1) < Finfo(ind,2)) & (unity*(ll2) >= Finfo(ind,2)));
                tmpW = W(ind(ind2),:);
                for jj=1:length(code_words)
                    Htmp{llcount}(i,jj) = sum(tmpW == code_words(jj));
                end;
            end;
            
            kernel_count = kernel_count + 1;
            K(:,:,kernel_count) = zeros(num_sample,num_sample);
            for i=1:num_sample
                for j=i:num_sample
                    K(i,j,kernel_count) = kernel_func(Htmp{llcount}(i,:),Htmp{llcount}(j,:));
                end;
            end;
            K(:,:,kernel_count) = K(:,:,kernel_count)+K(:,:,kernel_count)'- diag(diag(K(:,:,kernel_count)));

        end;
    end;
end;

if mode==0 || mode==2
    Ktmp = sum(K(:,:,end-4^L+1:end),3);
    start_ind = [1 2];    
    for l=0:(L-1)
        end_ind = start_ind + [4^l 4^(l+1)] -1;
        Ktmp = Ktmp + (sum(K(:,:,start_ind(1):end_ind(1)),3) - sum(K(:,:,start_ind(2):end_ind(2)),3))/(2^(L-l));
        start_ind = end_ind + 1;
    end;    
    if mode==0
        K = Ktmp;
    else
        K(:,:,end+1) = Ktmp;
    end;
end;