function h = chi2_kernel(x1,x2,gamma)
    ind = ((x1+x2)>0);
    %x1=x1(ind); x2=x2(ind);
    h = exp(-gamma^2*sum((x1(ind)/sum(x1)-x2(ind)/sum(x2)).^2./(x1(ind)+x2(ind)))); 

    
