function [K] = make_sift_kernel_from_var(var,mode,kernel_func)

if nargin < 2
    mode = 1;
end;
if nargin < 3
    kernel_func = @hist_intersection;
end;

for ii=1:length(var)
    L = 2;
    Ktmp = make_pyramid_kernel(var(ii).mincenter,var(ii).Finfo,var(ii).npoints,L,kernel_func,mode);
    if ii==1
        K = Ktmp;
        kern_ind = 1:size(Ktmp,3);
    else
        K(:,:,end+1:end+size(Ktmp,3)) = Ktmp;
        kern_ind = [(kern_ind(end)+1):(kern_ind(end)+size(Ktmp,3))];
    end;
end;

for ii=1:size(K,3)
    K(:,:,ii) = K(:,:,ii)/trace(K(:,:,ii));
end;