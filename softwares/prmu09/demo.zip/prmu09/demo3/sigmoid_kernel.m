function h = sigmoid_kernel(x1,x2,kappa,theta)
    h = tanh(kappa*(x1*x2')+theta); 

    
