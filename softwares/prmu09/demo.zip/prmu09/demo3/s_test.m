[F1,C1,nf1,np1,I1]=readcategory('prec/ant/*.txt',0.5);
[F2,C2,nf2,np2,I2]=readcategory('prec/crab/*.txt',0.5);

F=cell2mat([F1;F2]);
I=randperm(size(F,1));
[cent,mincent,mindist,q2,qual]=kmeans(F, F(I(1:200),:));