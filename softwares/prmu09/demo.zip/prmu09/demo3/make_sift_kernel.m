function [K Y vars] = make_sift_kernel(c_dir,base_dir,sift_type,mode)

if nargin < 4
    mode = 1;
end;

for sift_count=1:length(sift_type)
    F = [];
    Finfo = [];
    clear nfeat npoints
    class_count = 0;
    sample_count = 0;
    for ii=1:length(c_dir)
        class_count = class_count + 1;
        dir = [base_dir c_dir{ii} '\*_' sift_type{sift_count} '.txt'];
        if ispc
            S=ls(dir);
        else
            S=ls(dir,'-1');
        end;
        for jj=1:20 %size(S,1)
            sample_count = sample_count + 1;
            [F1,Inf,nfeat(sample_count),npoints(sample_count)] = readdescriptor([base_dir c_dir{ii} '\' S(jj,:)]);
            Y(sample_count) = ii;
            F = [F;F1];
            Finfo = [Finfo;Inf]; 
            SampleInd(sample_count) = class_count;
        end;
    end;

    num_center = 200;
    rind = randperm(size(F,1));
    [centers,mincenter,mindist,q2,quality] = kmeans2(F,F(rind(1:num_center),:));

    L = 2;
    Ktmp = make_pyramid_kernel(mincenter,Finfo,npoints,L,@hist_intersection,mode);
    if sift_count==1
        K = Ktmp;
        kern_ind = 1:size(Ktmp,3);
    else
        K(:,:,end+1:end+size(Ktmp,3)) = Ktmp;
        kern_ind = [(kern_ind(end)+1):(kern_ind(end)+size(Ktmp,3))];
    end;
    vars(sift_count) = struct('mincenter',mincenter,'npoints',npoints,'Finfo',Finfo,'shift_type',sift_type{sift_count},...
                               'kern_ind',kern_ind);
end;

for ii=1:size(K,3)
    K(:,:,ii) = K(:,:,ii)/trace(K(:,:,ii));
end;