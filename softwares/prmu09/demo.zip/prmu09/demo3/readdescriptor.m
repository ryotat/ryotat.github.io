function [F,C,nfeat,npoints] = readdescriptor(file)

fid=fopen(file);
fgetl(fid);
nfeat=str2num(fgetl(fid));
npoints=str2num(fgetl(fid));
fmt=char(['%f']'*ones(1,nfeat)); fmt=fmt(:)';
D=fscanf(fid,['<CIRCLE %f %f %f %f %f>; ' fmt ';\n']);
fclose(fid);

D=reshape(D,[nfeat+5,npoints])';

C=D(:,1:5);
F=D(:,6:end);