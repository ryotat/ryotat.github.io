c_dir = {'cannon','cup'};
base_dir = 'C:\Users\Suzuki\Documents\Study\Data Set\101_ObjectCategories\';
sift_type = {'hsvsift','sift','huesift','rgbhistogram'};

[K1 Y var1] = make_sift_kernel(c_dir,base_dir,{'hsvsift','sift'});
[K2 Y var2] = make_sift_kernel(c_dir,base_dir,{'huesift','rgbhistogram'});

K3 = make_sift_kernel_from_var(var1,1);
K4 = make_sift_kernel_from_var(var2,1);

K5 = [];
sigma_vec = linspace(1,50,5);
for sig=sigma_vec
    Ktmp = make_sift_kernel_from_var(var1,1,@(x,y)gauss_kernel(x,y,sig));
    if sig==sigma_vec(1)
        K5 = Ktmp;
    else
        K5 = addkernel(K5,Ktmp);
    end;
end;

kappa_vec = linspace(0.01,1,10);
theta_vec = -[10 100 500];
ii=0;
for kp=kappa_vec
    for th=theta_vec
        ii = ii+1;
        Ktmp = make_sift_kernel_from_var(var1,0,@(x,y)sigmoid_kernel(x,y,kp,th));
        if ii==1
            K6 = Ktmp;
        else
            K6 = addkernel(K6,Ktmp);
        end;
    end;
end;

d_vec = [1:5];
ii=0;
for dd = d_vec
    ii = ii+1;
    Ktmp = make_sift_kernel_from_var(var1,1,@(x,y)polynomial_kernel(x,y,dd));
    if ii==1
        K7 = Ktmp;
    else
        K7 = addkernel(K7,Ktmp);
    end;
end;

gamma_vec = linspace(1,50,10);
for gamma=gamma_vec
    Ktmp = make_sift_kernel_from_var(var1,1,@(x,y)chi2_kernel(x,y,gamma));
    if gamma==gamma_vec(1)
        K8 = Ktmp;
    else
        K8 = addkernel(K8,Ktmp);
    end;
end;

K=K3;
K=addkernel(K,K5);
K=addkernel(K,K7);
K=addkernel(K,K8);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

yapp = ((Y==1) - (Y==2))';

each_numtr = 15;
num_tr = each_numtr*2;
num_sample = size(K,1);
yout = unique(yapp);


options.stopdualitygap = 1;
options.stopIneqViolation = 0;
options.tolOuter = 0.01;
options.tolInner = 0.000001;
options.loss = 'logit';
options.display = 2;
C = 0.01;

test_error = [];
VALID_NUM = 40;
for VALID_STAGE=1:VALID_NUM
    tr_ind = [];
    for i=1:length(yout)
        ind = find(yapp==yout(i));
        ind = ind(randperm(length(ind)));
        tr_ind = [tr_ind; ind(1:each_numtr)];
    end;
    te_ind = setdiff(1:num_sample,tr_ind);


    [alpha,d,b,activeset,posind,params,story] = SpicyMKL(K(tr_ind,tr_ind,:),yapp(tr_ind),C,options);       
    Kte = concatkernel(K(te_ind,tr_ind,:),d);
    ypred = Kte(:,posind)*alpha(posind) + b;
    test_error(VALID_STAGE) = mean(sign(ypred)==yapp(te_ind));
end;
disp(['mean:' num2str(mean(test_error)) '  std:' num2str(std(test_error))]);
