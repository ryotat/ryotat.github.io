addpath ../dal/

%echo on;

m = 128;
n = 128;

try
  h=fspecial('gaussian',[11 11],5);
  H=convmtx2center(h, m, n);
catch
  load('H.mat');
end


X0=zeros(m,n); Yclean=zeros(m,n);
I=randperm(m*n);
X0(I(1:30))=1;
Yclean(:)=H*X0(:);
Y=Yclean+0.01*randn(m,n);
figure, imagesc(Y)                    

display('Press any key to continue.');
pause;

close;

lambda = 0.005;

[xx,stat]=dalsql1(zeros(m*n,1),H,Y(:),lambda,'eta',500,'solver','cg');

xx(xx<0.1)=0;

X=reshape(xx,[m,n]);
[ii,jj,ss]=find(X);
figure, 
subplot(1,2,1);
imagesc(Y)
title('True + Noise','FontSize',16);
axis image;
subplot(1,2,2);
imagesc(Yclean);
for kk=1:length(ss)
hold on; plot(jj(kk), ii(kk), 'mx', 'linewidth', 2,'markersize', 10);
end
title('True + Estimated','FontSize',16);
axis image;

