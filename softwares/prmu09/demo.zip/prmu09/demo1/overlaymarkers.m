function overlaymarkers(xx,m,n)

X=reshape(xx,[m,n]);
[ii,jj,ss]=find(X<0);
for kk=1:length(ss)
hold on; plot(jj(kk), ii(kk), 'mx', 'linewidth', 2,'markersize', 10);
end
[ii,jj,ss]=find(X>0);
for kk=1:length(ss)
hold on; plot(jj(kk), ii(kk), 'mo', 'linewidth', 2,'markersize', 10);
end


