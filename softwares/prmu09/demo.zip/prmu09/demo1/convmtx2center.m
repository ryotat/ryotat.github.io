function H = convmtx2center(h, m, n)

[mh, nh] = size(h); mh=(mh-1)/2; nh=(nh-1)/2;

mm = m+2*mh; nn= n+2*nh;

H = convmtx2(h, m, n);

Irm = repmat(1:mm, [1,nh]);
Jrm = reshape(ones(mm,1)*(1:nh),[1,mm*nh]);

for ii=1:n
  Irm = [Irm, 1:mh, mm-mh+(1:mh)];
  Jrm = [Jrm, (nh+ii)*ones(1,2*mh)];
end

Irm = [Irm, repmat(1:mm, [1,nh])];
Jrm = [Jrm, reshape(ones(mm,1)*(nn-nh+(1:nh)),[1,mm*nh])];

II = setdiff(1:mm*nn, sub2ind([mm,nn],Irm,Jrm));

H = H(II,:);