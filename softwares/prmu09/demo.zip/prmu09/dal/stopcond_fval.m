% stopcond_fval - objective value stopping condition 
%
% Copyright(c) 2009 Ryota Tomioka
% This software is distributed under the MIT license. See license.txt

function [ret, fval, spec, res]=stopcond_fval(ww, uu, aa, tol, prob, ...
                                              A, B, lambda);
fnc=prob.floss;
%% Evaluate primal loss

if ~isempty(uu)
  zz=A*ww+B*uu;
else
  zz=A*ww;
end

[fl, gg] =feval(fnc.p, zz, fnc.args{:});
spec=fevals(prob.fspec,ww);
fval = fl+lambda*sum(spec);

res  = fval-tol;
ret  = res<=0;
