% fevals - feval with parameters (substitute for function handles in <=R13)
%
% Copyright(c) 2009 Ryota Tomioka
% This software is distributed under the MIT license. See license.txt
function varargout=fevals(func, varargin)

if iscell(func)
  if length(func)>1
    param=func(2:end);
    func =func{1};
  else
    func =func{1};
    param=[];
  end
else
  param=[];
end

param = [varargin param];
varargout=cell(1,nargout);
[varargout{:}]=feval(func,param{:});