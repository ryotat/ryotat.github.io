% dallrgl - DAL with logistic loss and the L1 regularization
%
% Overview:
%  Solves the optimization problem:
%   [xx, bias] = argmin sum(log(1+exp(-yy.*(A*x+bias)))) + lambda*||x||_1
%
% Syntax:
%  [xx,bias,status]=dallrgl(xx, A, yy, lambda, <opt>)
%
% Inputs:
%  xx     : initial solution (nn x 1)
%  A      : the design matrix A (mm x nn)
%  yy     : the target label vector (-1 or +1) (mm x 1)
%  lambda : the regularization constant
%  <opt>  : list of 'fieldname1', value1, 'filedname2', value2, ...
%   stopcond : stopping condition, which can be
%              'pdg'  : Use relative primal dual gap (default)
%              'fval' : Use the objective function value
%           (see dal.m for other options)
% Outputs:
%  xx     : the final solution (nn x 1)
%  bias   : the final bias term (scalar)
%  status : various status values
%
% Copyright(c) 2009 Ryota Tomioka
% This software is distributed under the MIT license. See license.txt

function [ww,bias,status]=dallrl1(ww,bias, A, yy, lambda, varargin)

opt=propertylist2struct(varargin{:});
opt=set_defaults(opt,'solver','nt',...
                     'stopcond','pdg');



prob.floss    = struct('p',@loss_lrp,'d',@loss_lrd,'args',{{yy}});
prob.fspec    = @(xx)abs(xx);
prob.dnorm    = @(vv)max(abs(vv));
prob.obj      = @objdall1;
prob.softth   = @l1_softth;
prob.stopcond = ['stopcond_' opt.stopcond];
prob.ll       = min(0,yy);
prob.uu       = max(0,yy);
prob.Ac       =[];
prob.bc       =[];
prob.info     =[];

if isequal(opt.solver,'cg')
  prob.hessMult = @hessMultdall1;
end

if isequal(opt.stopcond,'fval')
  opt.feval = 1;
end

opt.aa = yy/2;

[mm,nn]=size(A);
prob.mm       = mm;
prob.nn       = nn;

[ww,bias,status]=dal(prob,ww,bias,A,ones(mm,1),lambda,opt);

