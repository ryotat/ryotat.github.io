%% Example of squared-loss-groued-L1 DAL on a synthetic problem (non-sparse)

m = 1024; ns = 64; nc=64;
gmax=@(x)max(sqrt(sum(reshape(x,[ns,nc]).^2)));
A=randn(m,ns,nc);
w0=randn(ns,nc);
bb=A(:,:)*w0(:)+randn(m,1);
lambda=0.5*gmax(A(:,:)'*bb);

lambda = lambda*[1 0.1 0.01 1e-3 1e-4];
time   = zeros(size(lambda));
spar   = zeros(size(lambda));
xx     = zeros(ns*nc,length(lambda));
t0     = cputime;
xx1    = zeros(ns,nc);
for ii=1:length(lambda)
  [xx1,stat]=dalsqgl(xx1,A(:,:),bb,lambda(ii),'display',3);
  xx(:,ii)=xx1(:);
  time(ii)=cputime-t0;
  spec    =sqrt(sum(xx1.^2));
  spar(ii)=sum(spec>10*median(spec))/nc;
  fprintf('lambda=%g sparsity=%g%% time=%g\n',lambda(ii), spar(ii)*100, time(ii));
end



