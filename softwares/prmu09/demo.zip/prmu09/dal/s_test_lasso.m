%% Example of squared-loss-L1 DAL on a synthetic problem (non-sparse)

m = 1024;
n = 4096;
A=randn(m,n);
w0=randn(n,1);
bb=A*w0+0.01*randn(m,1);
lambda=0.1*max(abs(A'*bb));

lambda = lambda*[1 0.1 0.01 1e-3 1e-4];
time   = zeros(size(lambda));
spar   = zeros(size(lambda));
xx     = zeros(n,length(lambda));
t0     = cputime;
xx1    = zeros(n,1);
for ii=1:length(lambda)
  xx1=dalsql1(xx1,A,bb,lambda(ii));
  xx(:,ii)=xx1;
  time(ii)=cputime-t0;
  spar(ii)=full(sum(abs(xx1)>0)/n);
  fprintf('lambda=%g sparsity=%g%% time=%g\n',lambda(ii), spar(ii)*100, time(ii));
end

