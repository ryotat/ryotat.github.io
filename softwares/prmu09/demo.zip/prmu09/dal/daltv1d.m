% daltv1d - DAL for 1D TV denoising
%
% Overview:
%  Solves the optimization problem:
%   xx = argmin ||A*x-bb|| + lambda*||diff(x)||_1
%
% Syntax:
%  [xx,status]=dallrgl(xx, A, bb, lambda, <opt>)
%
% Inputs:
%  xx     : initial solution ([nn,1])
%  A      : the design matrix A ([mm,nn]) or a cell array {fA, fAT, mm, nn}
%           where fA and fAT are function handles to the functions that
%           return A*x and A'*x, respectively, and mm and nn are the
%           numbers of rows and columns of A.
%  bb     : the target vector ([mm,1])
%  lambda : the regularization constant
%  <opt>  : list of 'fieldname1', value1, 'filedname2', value2, ...
%   stopcond : stopping condition, which can be
%              'pdg'  : Use relative primal dual gap (default)
%              'fval' : Use the objective function value
%           (see dal.m for other options)
% Outputs:
%  xx     : the final solution ([nn,1])
%  status : various status values
%
% Copyright(c) 2009 Ryota Tomioka
% This software is distributed under the MIT license. See license.txt

function [ww,status]=daltv1d(ww,A,bb, lambda, varargin)

opt=propertylist2struct(varargin{:});
opt=set_defaults(opt,'solver','nt',...
                     'stopcond','pdg');



prob.floss    = struct('p',@loss_sqp,'d',@loss_sqd,'args',{{bb}});
prob.fspec    = @(xx)abs(xx);
prob.dnorm    = @(vv)max(abs(vv));
prob.obj      = @objdall1;
prob.softth   = @l1_softth;
prob.stopcond = ['stopcond_' opt.stopcond];
prob.ll       = -inf*ones(size(bb));
prob.uu       = inf*ones(size(bb));
prob.Ac       =[];
prob.bc       =[];
prob.info     =[];

if isequal(opt.solver,'cg')
  prob.hessMult = @hessMultdall1;
end

if isequal(opt.stopcond,'fval')
  opt.feval = 1;
end

[mm,nn]=size(A);
prob.mm       = mm;
prob.nn       = nn-1;


uu=ww(end);
xx=-diff(ww);


A=cumsum(A')';
B=A(:,end);
A=A(:,1:end-1);

[xx,uu,status]=dal(prob,xx,uu,A,B,lambda,opt);

ww=flipud(cumsum(flipud(xx)));
ww=[ww+uu; uu];
