% dallrgl - DAL with logistic loss and grouped L1 regularization
%
% Overview:
%  Solves the optimization problem:
%   [xx,bias] = argmin sum(log(1+exp(-yy.*(A*x+bias)))) + lambda*||x||_G1
%  where
%   ||x||_G1 = sum(sqrt(sum(xx.^2)))
%   (grouped L1 norm)
%
% Syntax:
%  [ww,bias,status]=dallrgl(ww, A, yy, lambda, <opt>)
%
% Inputs:
%  ww     : initial solution (nn x 1)
%  A      : the design matrix A (mm,nn)
%  yy     : the target label vector (-1 or +1) (mm x 1)
%  lambda : the regularization constant
%  <opt>  : list of 'fieldname1', value1, 'filedname2', value2, ...
%   stopcond : stopping condition, which can be
%              'pdg'  : Use relative primal dual gap (default)
%              'fval' : Use the objective function value
%           (see dal.m for other options)
% Outputs:
%  ww     : the final solution (nn x 1)
%  bias   : the final bias term (scalar)
%  status : various status values
%
% Copyright(c) 2009 Ryota Tomioka
% This software is distributed under the MIT license. See license.txt

function [ww,uu,status]=dallrgl(ww, A, yy, lambda, varargin)

opt=propertylist2struct(varargin{:});
opt=set_defaults(opt,'solver','nt',...
                     'stopcond','pdg',...
                     'blks',[]);

if isempty(opt.blks)
  opt.blks=size(ww,1)*ones(1,size(ww,2));
  ww = ww(:);
end

prob.floss    = struct('p',@loss_lrp,'d',@loss_lrd,'args',{{yy}});
prob.fspec    = {@gl_spec, opt.blks};
prob.dnorm    = {@gl_dnorm, opt.blks};
prob.obj      = @objdalgl;
prob.softth   = @gl_softth;
prob.stopcond = ['stopcond_' opt.stopcond];
prob.ll       = min(0,yy);
prob.uu       = max(0,yy);
prob.Ac       =[];
prob.bc       =[];
prob.info     = struct('blks',opt.blks);

if isequal(opt.solver,'cg')
  prob.hessMult = @hessMultdalgl;
end

if isequal(opt.stopcond,'fval')
  opt.feval = 1;
end

opt.aa = yy/2;

[mm,nn]=size(A);
prob.mm       = mm;
prob.nn       = nn;

[ww,uu,status]=dal(prob,ww,0,A,ones(mm,1),lambda,opt);


if all(opt.blks==opt.blks(1))
  ns=opt.blks(1);
  nc=length(ww)/ns;
  ww=reshape(ww, [ns,nc]);
end
