% stopcond_pdg - "primal-dual" stopping condition
%
% Copyright(c) 2009 Ryota Tomioka
% This software is distributed under the MIT license. See license.txt

function [ret, fval, spec, res]=stopcond_pdg(ww, uu, aa, tol, prob, A, B, lambda)

fnc=prob.floss;
%% Evaluate primal loss

if ~isempty(uu)
  zz=A*ww+B*uu;
else
  zz=A*ww;
end

[fl, gg] =feval(fnc.p, zz, fnc.args{:});
spec=fevals(prob.fspec,ww);
fval = fl+lambda*sum(spec);


if isfield(prob,'Aeq')
  vv = [A', prob.Aeq']*aa;
  fval = fval+norm(prob.Aeq*ww-prob.ceq)^2/tol;
else
  vv = A'*aa;
end
dnm = fevals(prob.dnorm, vv);

if dnm>0
  aa    = min(1, lambda/dnm)*aa;
end

if ~isempty(uu)
  if isfield(prob,'Aeq')
    aa=aa(1:end-prob.meq);
  end
  aa=aa-B*((B'*B)\(B'*aa));
end


dloss = feval(fnc.d, aa, fnc.args{:});
res   = fval-(-dloss);
res   = res/fval;

ret   = (res<tol);

if res<0
  ret=0;
  res=inf;
end

