% hessMultdalgl - function that computes H*x for DAL with grouped
%                 L1 regularization
%
% Copyright(c) 2009 Ryota Tomioka
% This software is distributed under the MIT license. See license.txt

function yy = hessMultdalgl(xx, A, eta, Hinfo)

blks =Hinfo.blks;
hloss=Hinfo.hloss;
I    =Hinfo.I;
vv   =Hinfo.vv;
nm   =Hinfo.nm;
lambda=Hinfo.lambda;

yy = hloss*xx;


for kk=1:length(I)
  jj=I(kk);
  J=sum(blks(1:jj-1))+(1:blks(jj));
  vn=vv(J)/nm(jj);
  ff=lambda/nm(jj);
  
  % AF=ff*A(:,J)+(1-ff)*A(:,J)*vn*vn';

  xk=A(:,J)'*xx;
  
  yy = yy + eta*A(:,J)*((1-ff)*xk+ff*vn*(vn'*xk));
end

B=Hinfo.B;
if ~isempty(B)
  yy = yy + eta*B*(B'*xx);
end
