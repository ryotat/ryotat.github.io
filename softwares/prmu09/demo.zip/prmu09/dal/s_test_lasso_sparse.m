%% Example of squared-loss-L1 DAL on a synthetic problem (sparse)

m = 1024;
n = 4096;
% k = round(0.04*n);
k = 160;
A=randn(m,n);
I=randperm(n);w0=zeros(n,1);w0(I(1:k))=sign(randn(k,1));
bb=A*w0+0.01*randn(m,1);
lambda=0.1*max(abs(A'*bb));

lambda = lambda*[1 0.1 0.01 1e-3 1e-4];
time   = zeros(size(lambda));
xx     = zeros(n,length(lambda));
t0     = cputime;
xx1    = zeros(n,1);
for ii=1:length(lambda)
  xx1=dalsql1(xx1,A,bb,lambda(ii),'solver','nt');
  xx(:,ii)=xx1;
  time(ii)=cputime-t0;
  sparse  =full(sum(abs(xx1)>0)/n);
  fprintf('lambda=%g sparsity=%g%% time=%g\n',lambda(ii), sparse*100, time(ii));
end

