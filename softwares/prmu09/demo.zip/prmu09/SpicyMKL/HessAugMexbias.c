#include "mex.h"
#include "blas.h"
#include "lapack.h"
#include <math.h>

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    double *K, *activeset, *v, *wj,  *cgamma, *HessAug;
    int ind;
    double one = 1.0, zero = 0.0, alpha, C, cgammab;
    int oneint = 1; 
    int N,M,len, NN;
    int j;
    int *Kdims;
    char *chn = "N";

    K = mxGetPr(prhs[0]);
    wj = mxGetPr(prhs[1]);
    activeset = mxGetPr(prhs[2]);
    v = mxGetPr(prhs[3]);
    C = mxGetScalar(prhs[4]);
    cgamma = mxGetPr(prhs[5]);
    cgammab = mxGetScalar(prhs[6]);
    

    Kdims = (int*)mxGetDimensions(prhs[0]);
    N = Kdims[0];
    if(mxGetNumberOfDimensions(prhs[0])==3) {
      M = Kdims[2];
    }
    else {
      M = 1;
    }

    len = mxGetN(prhs[2]);
    NN = N*N;

    plhs[0] = mxCreateDoubleMatrix(N,N,mxREAL);
    HessAug = mxGetPr(plhs[0]);
    memcpy(HessAug,mxGetPr(prhs[7]),N*N*sizeof(HessAug[0]));
    
    for(j=0;j<len;j++){
        ind = (int)activeset[j] -1;
        alpha = cgamma[ind]*(wj[ind]-C)/wj[ind];
        daxpy(&NN, &alpha, &K[NN*ind], &oneint, HessAug, &oneint);
        alpha = cgamma[ind]*C/(wj[ind]*wj[ind]*wj[ind]);
        dger(&N, &N, &alpha, &v[ind*N], &oneint, &v[ind*N], &oneint, HessAug, &N );
    };
    for(j=0;j<NN;j++){
        HessAug[j] = HessAug[j] + cgammab;   
    };

};
