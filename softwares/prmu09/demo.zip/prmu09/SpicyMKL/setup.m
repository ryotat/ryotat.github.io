mex -lmwblas normKj.c
mex -lmwblas HessAugMexbias.c
