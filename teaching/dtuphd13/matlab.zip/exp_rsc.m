[X,Y]=meshgrid([-20:20]);

figure

subplot(1,2,1);
surf(X, Y, abs(X-0.5*Y));
hold on; surf(X, Y, sqrt(X.^2+Y.^2)-0.8*(abs(X)+abs(Y)));
set(gca,'fontsize',16);
title('Lucky case');
xlabel('v_1');
ylabel('v_2');
view([-26.5, 34]);

subplot(1,2,2);
surf(X, Y, abs(X));
hold on; surf(X, Y, sqrt(X.^2+Y.^2)-0.8*(abs(X)+abs(Y)));
set(gca,'fontsize',16);
title('Unlucky case');
xlabel('v_1');
ylabel('v_2');
view([-26.5, 34]);

