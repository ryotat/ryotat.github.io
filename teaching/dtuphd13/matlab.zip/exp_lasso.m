addpath dal
m = 1024; n = 4096; k = round(0.04*n); A=randn(m,n);
w0=randsparse(n,k); bb=A*w0+0.01*randn(m,1);
lambda=0.1*max(abs(A'*bb));
[ww,stat]=dalsql1(zeros(n,1), A, bb, lambda);

figure
subplot(2,1,1); plot(w0);
set(gca,'fontsize',14);
title('Truth');
xlim([0, n]);

subplot(2,1,2); plot(ww);
set(gca,'fontsize',14);
title('Estimated');
xlim([0, n]);