clear all;

ns=[500, 1000, 10000];
p=100;

for kk=1:length(ns)
  n=ns(kk);
  L1=(sqrt(p)+sqrt(n))^2;
  L2=(-sqrt(p)+sqrt(n))^2;

  A=randn(n,p);
  
  % Compute the singular values
  ss(:,kk)=svd(A)/sqrt(n);
  
end

figure;
plot(ss, 'linewidth', 2);
grid on;
set(gca,'fontsize',14)
xlabel('Order')
ylabel('Singular values/sqrt(n)');

legend(cellfun(@(x)sprintf('n=%d',x),num2cell(ns),'uniformoutput',0));

