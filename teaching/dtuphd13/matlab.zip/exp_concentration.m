ns=[100, 1024, 10000];
for ii=1:length(ns)
  % Generate 10000 random n dimensional vectors
  X=randn(ns(ii),10000);
  
  % Compute the norms
  N=sqrt(sum(X.^2));

  subplot(1,length(ns),ii);
  
  % Plot the histogram of norms
  hist(N);
  xlim([-5 5]+sqrt(ns(ii)));
  set(gca,'fontsize',14);
  xlabel('||x||');
  grid on;
  ylabel('Frequency');
  hold on;

  % Plot the approx mean sqrt(n)
  plot([1 1]*sqrt(ns(ii)), ylim, 'm--', 'linewidth', 2);

  % Plot sqrt(n)-1
  plot([1 1]*(sqrt(ns(ii))-1), ylim, 'g--', 'linewidth', 2);

  % Plot sqrt(n)+1
  plot([1 1]*(sqrt(ns(ii))+1), ylim, 'g--', 'linewidth', 2);
  title(sprintf('n=%d',ns(ii)));
end
