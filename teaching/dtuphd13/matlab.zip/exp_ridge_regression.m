nrep=100;

sigma=1;
p=100;
ns=10:5:200;
lambda=1e-6;

w0=randn(p,1);

for jj=1:length(ns)
  n=ns(jj);
  X=randn(n,p);
  for ii=1:nrep
    yy=X*w0+sigma*randn(n,1);
    
    if n>p
      ww=(X'*X+lambda*eye(p))\(X'*yy);
    else
      ww=X'*((X*X'+lambda*eye(n))\yy);
    end
    
    err(ii,jj)=norm(ww-w0)^2;
  end
end

figure,h=errorbar(ns, mean(err), std(err));
set(h,'linewidth',2);
set(gca,'fontsize',16);
xlabel('Number of samples n');
ylabel('Generalization error ||w-w*||^2');
grid on;
  