addpath dal

nrep=10;
sigma=0.01;
k=10;

ps = 100:100:1000;
ns = 100:10:200;

err=zeros(length(ns), length(ps), nrep);

for ll=1:nrep
  for ii=1:length(ns)
    n=ns(ii);
    for jj=1:length(ps)
      p=ps(jj);
      X=randn(n,p);
      w0=randsparse(p,k);
      yy=X*w0+sigma*randn(n,1);
      lambda=sigma*sqrt(log(p)/n);
      [ww,stat]=dalsql1(zeros(p,1), X, yy, n*lambda,'display',1);
      err(ii,jj,ll)=norm(ww-w0);
      fprintf('n=%d p=%d error=%g\n', n, p, err(ii,jj));        
    end
  end
end
figure, imagesc(ps, ns, mean(err,3));
hold on; plot(ps, 20*log(ps), 'm--', 'linewidth', 2);
hold on; plot(ps, 25*log(ps), 'm--', 'linewidth', 2);
hold on; plot(ps, 30*log(ps), 'm--', 'linewidth', 2);

set(gca,'fontsize',14)
colorbar;

xlabel('p');
ylabel('n');

title('Average error ||w^-w*||','interpreter','none');


ix=[1,2,4,8];
figure, 
h=errorbar_logsafe(ns'*(1./log(ps(ix))), mean(err(:,ix,:),3), std(err(:,ix,:),[],3));
set(h,'linewidth',2);
grid on;
set(gca,'fontsize',14);
xlabel('n/log(p)');
ylabel('Error ||w^-w*||','interpreter','none');
legend(cellfun(@(x)sprintf('p=%d',x), num2cell(ps(ix)), ...
               'uniformoutput',0));
