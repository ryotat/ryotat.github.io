sigma=1;
ps=10:10:100;
nrep=100000;

for ii=1:length(ps)
  p=ps(ii);
  X=sigma*randn(p,nrep);
  frac(ii,1)=mean(max(abs(X))>1.5*sigma*sqrt(log(p)));
  frac(ii,2)=mean(max(abs(X))>2*sigma*sqrt(log(p)));
end

figure, loglog(ps, frac, ps, 2./ps, 'm--', 'linewidth', 2)
grid on;
set(gca,'fontsize',16);
xlabel('p');
ylabel('Prob(max_j |z_j|> c \sigma log^{1/2}(p))');
legend('c=1.5','c=2','2/p');
