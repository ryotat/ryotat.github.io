R=100;
C=100;
k=5;

Y0 = randn(R,k)*randn(k,C);

ind=randperm(R*C); ind=ind(1:R*C/2);
ind_te = setdiff(1:R*C, ind);

Y=Y0;
Y(ind_te)=0;

[X,stat]=svt(Y,0.00001,55);

figure
subplot(1,4,1);
plot(1-stat.dval./stat.fval, '-x', 'linewidth',2);
title('Relative duality gap');
set(gca,'yscale','log');

subplot(1,4,2);
plot(Y0(ind),X(ind),'x'); grid on;
title('Training');

subplot(1,4,3);
plot(Y0(ind_te),X(ind_te),'x'); grid on;
title('Test');

subplot(1,4,4);
plot([svd(Y0), svd(X)],'-x','linewidth',2);
title('Singularvalues');
legend('True','Estimated');

set(gcf,'position',[1, 410, 1039, 274]);