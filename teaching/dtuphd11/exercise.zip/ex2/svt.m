function [X,stat]=svt(Y, lambda, tau, tol, maxiter, eta)

% Tolerance
if ~exist('tol','var') || isempty(tol)
  tol=1e-3;
end

% Maximum number of iterations
if ~exist('maxiter','var') || isempty(maxiter)
  maxiter=1000;
end

% Step-size
if ~exist('eta','var') || isempty(eta)
  eta=1;
end

[R,C]=size(Y);
[I,J,yy]=find(Y);
ind = sub2ind([R,C],I,J);

m=length(I);

% Initialize the solution
X=zeros(R,C);
zz=yy;
alpha=zeros(m,1);

% kk denotes the number of iterations
kk=1;

nc = 10;
ss=zeros(nc,1);
% Main loop starts here
while 1
  alpha_old = alpha;
 
  % Implement dual ascent method here

  
  % Evaluate objective
  fval(kk) = 0.5*sum((X(ind)-yy).^2)/lambda+tau*sum(ss)+0.5*sum(X(:).^2);
  dval(kk) = evaldual(alpha_old,yy,ss,lambda,tau);

  % Print progress
  fprintf('[%d] fval=%g dval=%g sparsity=%g\n', kk, fval(kk), dval(kk), nc);
  
  % Monitor progress
  if 1-dval(kk)/fval(kk) < tol
    break;
  end
  
  if kk==maxiter
    break;
  end
  
  kk=kk+1;
end


stat=struct('niter',kk,'fval',fval,'dval', dval);

function dval=evaldual(alpha,yy,ss,lambda,tau)

dval = -0.5*lambda*sum(alpha.^2)+alpha'*yy...
       -0.5*sum(ss.^2);