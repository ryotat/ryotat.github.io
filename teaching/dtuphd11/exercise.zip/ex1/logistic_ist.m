function [ww, stat]=logistic_ist(X, yy, lambda, tol, maxiter)

if ~exist('tol','var') || isempty(tol)
  tol=1e-6;
end

if ~exist('maxiter','var') || isempty(maxiter)
  maxiter=1000;
end

[m,n]=size(X);
A =sparse(1:m, 1:m, yy, m,m)*X;

% Step-size
eta=1/256;

% Initialize the solution
ww=zeros(n,1);
gloss=zeros(m,1);

% kk denotes the number of iterations
kk=1;


% Main loop starts here
while 1
  % Implement iterative shrinkage/threshold algorithm here


  % Evaluate objective
  fval(kk) = sum(log(1+exp(-(A*ww))))+lambda*sum(abs(ww));
  dval(kk) = evaldual(gloss, A, lambda);
  
  % Print progress
  fprintf('[%d] fval=%g dval=%g sparsity=%g\n', kk, fval(kk), dval(kk), sum(abs(ww)>0));
  
  % Monitor progress
  if 1-dval(kk)/fval(kk) < tol
    break;
  end
  
  if kk==maxiter
    break;
  end
  
  kk=kk+1;
end

stat=struct('niter',kk,'fval',fval,'dval',dval);


function dval=evaldual(alpha, A, lambda)

alpha = lambda*alpha/max([lambda;abs(A'*alpha)]);
dval = -sum(alpha.*log(alpha)+(1-alpha).*log(1-alpha));