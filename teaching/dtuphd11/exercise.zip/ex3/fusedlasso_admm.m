function [xx, stat]=fusedlasso_admm(yy, lambda, tol, maxiter, eta)

% Tolerance
if ~exist('tol','var') || isempty(tol)
  tol=1e-3;
end

% Maximum number of iterations
if ~exist('maxiter','var') || isempty(maxiter)
  maxiter=1000;
end

% Step-size
if ~exist('eta','var') || isempty(eta)
  eta=100;
end

n=length(yy);

% A matrix
A = sparse([1:n-1, 1:n-1],[1:n-1, 2:n],[-ones(1,n-1), ones(1,n-1)],n-1,n);

% Cholesky factor
R = chol(speye(n)+eta*A'*A);

% Initialize the solution
xx=zeros(n,1);
zz=zeros(n-1,1);
alpha=zeros(n-1,1);

% kk denotes the number of iterations
kk=1;

% Main loop starts here
while 1
  % Implement ADMM here


  % Evaluate objective
  fval(kk) = 0.5*sum((xx-yy).^2)+lambda*sum(abs(A*xx));
  dval(kk) = evaldual(alpha, yy, A, lambda);
  
  % Print progress
  fprintf('[%d] fval=%g dval=%g sparsity=%g\n', kk, fval(kk), dval(kk), ...
          sum(abs(zz)>0));
  
  % Monitor progress
  if (fval(kk)-dval(kk))/fval(kk) < tol
    break;
  end
  
  if kk==maxiter
    break;
  end

  kk=kk+1;
end


stat=struct('niter',kk,'fval',fval);

function dval=evaldual(alpha, yy, A, lambda)

% project alpha to max(abs(alpha))<=1
alpha = lambda*alpha/max([lambda;abs(alpha)]);
dval = -0.5*sum((A'*alpha).^2)-alpha'*A*yy;

