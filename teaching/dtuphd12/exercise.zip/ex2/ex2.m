% load data
load data.mat


[ww,stat]=fusedlasso_admm(yy, 10);


figure, plot([x0, yy, ww], '-x','linewidth',2);
legend('True','Noisy','Estimated');