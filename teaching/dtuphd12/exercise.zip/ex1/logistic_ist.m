function [ww, stat]=logistic_ist(X, yy, lambda, tol, maxiter)

if ~exist('tol','var') || isempty(tol)
  tol=1e-6;
end

if ~exist('maxiter','var') || isempty(maxiter)
  maxiter=1000;
end

[m,n]=size(X);
A= bsxfun(@times, X, yy);

% Step-size
eta=10/(sqrt(m)+sqrt(n))^2;

% Initialize the solution
ww=zeros(n,1);

% kk denotes the number of iterations
kk=1;


% Main loop starts here
while 1
  % Implement iterative shrinkage/threshold algorithm here
  gloss = -exp(-(A*ww))./(1+exp(-(A*ww)));
  ww1 = ww - eta*(A'*gloss);
  ww = softth(ww1, lambda*eta);
  
  % Evaluate objective
  fval(kk) = sum(log(1+exp(-(A*ww))))+lambda*sum(abs(ww));
  
  % Print progress
  fprintf('[%d] fval=%g sparsity=%g\n', kk, fval(kk), sum(abs(ww)>0));
  
  % Monitor progress and stop if the decrease in the function value
  % is smaller than tol. If you can, implement a relative duality
  % gap based stopping criterion here.
  if kk>1 && fval(kk-1)-fval(kk) < tol
    break;
  end
  
  if kk==maxiter
    break;
  end
  
  kk=kk+1;
end

stat=struct('niter',kk,'eta',eta,'fval',fval);


function ww=softth(ww, lambda)
ww=max(abs(ww)-lambda,0).*sign(ww);


