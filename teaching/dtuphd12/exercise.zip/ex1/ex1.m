clear all;
m = 1000;  % number of samples
n = 4000;  % number of variables
k = round(0.01*n); % number of active variables

X=randn(m,n); % Design matrix

w0=randsparse(n,k); % True vector

yy=sign(X*w0+0.01*randn(m,1));
lambda=0.1*max(abs(X'*yy));


% Estimation
[ww,stat]=logistic_ist(X, yy, lambda, 1e-9);

% Compute ROC curve
[ss,ix]=sort(-abs(ww));
w0sorted=w0(ix);
fp = cumsum(w0sorted==0);
tp = cumsum(abs(w0sorted)>0);


% Plotting
figure
subplot(2,1,1); plot(w0);
title('True');

subplot(2,1,2); plot(ww);
title('Estimated');

figure
plot(fp,tp, 'x--', 'linewidth',2);